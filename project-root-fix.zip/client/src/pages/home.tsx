import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Send, CheckCircle2, AlertCircle, QrCode, Wifi, LogOut } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import QRCode from "qrcode";

interface WhatsAppStatus {
  ready: boolean;
  qrCode: string | null;
  message: string;
}

export default function Home() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [message, setMessage] = useState("");
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const { toast } = useToast();

  // Poll WhatsApp status every 2 seconds
  const { data: status, isLoading: statusLoading } = useQuery<WhatsAppStatus>({
    queryKey: ["/api/status"],
    refetchInterval: 2000,
  });

  // Generate QR code image when QR data is available
  useEffect(() => {
    if (status?.qrCode) {
      QRCode.toDataURL(status.qrCode, {
        width: 300,
        margin: 2,
        color: {
          dark: "#000000",
          light: "#FFFFFF",
        },
      })
        .then((url: string) => setQrCodeUrl(url))
        .catch((err: Error) => console.error("QR code generation error:", err));
    } else {
      setQrCodeUrl(null);
    }
  }, [status?.qrCode]);

  // Send message mutation
  const sendMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/send-direct', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          number: phoneNumber,
          message: message
        })
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to send message');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/status"] });
    },
  });

  // Reset session mutation
  const resetSessionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/whatsapp/reset-session", {});
    },
    onSuccess: () => {
      toast({
        title: "تم إعادة تعيين الجلسة",
        description: "سيظهر QR code جديد خلال لحظات. الجهاز المرتبط السابق لا يزال مرتبطاً من جهته.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/status"] });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "خطأ",
        description: error.message || "فشل في إعادة تعيين الجلسة",
      });
    },
  });

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || !message || !status?.ready) return;
    sendMutation.mutate();
  };

  const isConnected = status?.ready === true;
  const hasQrCode = status?.qrCode && qrCodeUrl;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <Card>
          <CardHeader className="space-y-1">
            <CardTitle className="text-3xl font-bold tracking-tight">
              WhatsApp Message Sender
            </CardTitle>
            <CardDescription className="text-sm">
              Send WhatsApp messages through a free web interface
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Connection Status Banner */}
            {statusLoading ? (
              <Alert>
                <Loader2 className="h-4 w-4 animate-spin" />
                <AlertDescription>Initializing WhatsApp connection...</AlertDescription>
              </Alert>
            ) : isConnected ? (
              <div className="space-y-4">
                <Alert className="border-primary/50 bg-primary/5" data-testid="status-connected">
                  <Wifi className="h-4 w-4 text-primary" />
                  <AlertDescription className="text-primary font-medium">
                    ✓ WhatsApp Connected - Ready to send messages
                  </AlertDescription>
                </Alert>
                <Button
                  variant="outline"
                  onClick={() => resetSessionMutation.mutate()}
                  disabled={resetSessionMutation.isPending}
                  className="w-full"
                  data-testid="button-reset-session"
                >
                  {resetSessionMutation.isPending ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      جاري إعادة التعيين...
                    </>
                  ) : (
                    <>
                      <LogOut className="ml-2 h-4 w-4" />
                      تسجيل الخروج وربط حساب جديد
                    </>
                  )}
                </Button>
              </div>
            ) : hasQrCode ? (
              <Alert className="border-yellow-500/50 bg-yellow-500/5" data-testid="status-qr">
                <QrCode className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-600 font-medium">
                  Scan QR code below to connect WhatsApp
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="border-muted-foreground/50" data-testid="status-connecting">
                <Loader2 className="h-4 w-4 animate-spin" />
                <AlertDescription>Connecting to WhatsApp...</AlertDescription>
              </Alert>
            )}

            {/* QR Code Display */}
            {hasQrCode && (
              <div className="flex flex-col items-center justify-center p-6 bg-card rounded-lg border space-y-4" data-testid="qr-code-container">
                <img 
                  src={qrCodeUrl} 
                  alt="WhatsApp QR Code" 
                  className="w-64 h-64 rounded-md shadow-md"
                  data-testid="qr-code-image"
                />
                <div className="text-center space-y-1">
                  <p className="text-sm font-medium">Scan with WhatsApp Mobile</p>
                  <p className="text-xs text-muted-foreground">
                    Open WhatsApp → Settings → Linked Devices → Link a Device
                  </p>
                </div>
              </div>
            )}

            {/* Message Form */}
            <form onSubmit={handleSend} className="space-y-6">
              {/* Phone Number Input */}
              <div className="space-y-2">
                <Label htmlFor="phone-number" className="text-sm font-medium uppercase tracking-wide">
                  Phone Number
                </Label>
                <Input
                  id="phone-number"
                  type="tel"
                  placeholder="+1234567890 (with country code)"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  disabled={!isConnected}
                  className="h-12"
                  data-testid="input-phone"
                />
                <p className="text-xs text-muted-foreground">
                  Include country code (e.g., +1 for US, +44 for UK, +91 for India)
                </p>
              </div>

              {/* Message Textarea */}
              <div className="space-y-2">
                <Label htmlFor="message" className="text-sm font-medium uppercase tracking-wide">
                  Message
                </Label>
                <Textarea
                  id="message"
                  placeholder="Type your message here..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  disabled={!isConnected}
                  className="h-32 resize-none"
                  maxLength={4096}
                  data-testid="input-message"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Maximum 4096 characters</span>
                  <span data-testid="text-char-count">{message.length} / 4096</span>
                </div>
              </div>

              {/* Send Button */}
              <Button
                type="submit"
                disabled={!isConnected || !phoneNumber || !message || sendMutation.isPending}
                className="w-full h-12 text-base font-semibold"
                data-testid="button-send"
              >
                {sendMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Send Message
                  </>
                )}
              </Button>
            </form>

            {/* Success/Error Feedback */}
            {sendMutation.isSuccess && (
              <Alert className="border-primary/50 bg-primary/5" data-testid="alert-success">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <AlertDescription className="text-primary">
                  Message sent successfully!
                </AlertDescription>
              </Alert>
            )}

            {sendMutation.isError && (
              <Alert className="border-destructive/50 bg-destructive/5" data-testid="alert-error">
                <AlertCircle className="h-4 w-4 text-destructive" />
                <AlertDescription className="text-destructive">
                  {(sendMutation.error as any)?.message || "Failed to send message. Please try again."}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Footer Info */}
        <div className="mt-6 text-center">
          <p className="text-xs text-muted-foreground font-medium">
            Developed with ❤️ by JOSEPH FADY
          </p>
        </div>
      </div>
    </div>
  );
}
