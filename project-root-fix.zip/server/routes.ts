import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { randomBytes } from "crypto";
import { 
  initializeAllWhatsAppAccounts, 
  getAccountState, 
  getAllAccountStates,
  initializeWhatsAppAccount,
  disconnectWhatsAppAccount,
  deleteWhatsAppAccountSession,
  sendMessageFromAccount 
} from "./whatsapp";
import { storage } from "./storage";
import { insertApiKeySchema, insertWhatsAppAccountSchema } from "@shared/schema";

// Validation schema for send message request
const sendMessageSchema = z.object({
  number: z.string()
    .min(10, "Phone number must be at least 10 digits")
    .regex(/^\+?\d+$/, "Phone number must contain only digits and optional leading +"),
  message: z.string()
    .min(1, "Message cannot be empty")
    .max(4096, "Message is too long (max 4096 characters)")
});

// Validation schema for creating API key
const createApiKeySchema = z.object({
  name: z.string().min(1, "Name is required").max(100, "Name is too long"),
  customKey: z.string().optional(),
});

// Helper function to generate a secure API key
function generateApiKey(): string {
  return `wapi_${randomBytes(32).toString('hex')}`;
}

// Middleware to validate API key for WhatsApp endpoints
async function validateApiKey(req: Request, res: Response, next: NextFunction) {
  const apiKey = req.headers['x-api-key'] as string;
  
  if (!apiKey) {
    return res.status(401).json({
      success: false,
      error: 'API key is required. Please provide your API key in the X-API-Key header.'
    });
  }
  
  const keyRecord = await storage.getApiKeyByKey(apiKey);
  
  if (!keyRecord) {
    return res.status(401).json({
      success: false,
      error: 'Invalid API key.'
    });
  }
  
  if (!keyRecord.isActive) {
    return res.status(403).json({
      success: false,
      error: 'This API key has been disabled.'
    });
  }
  
  await storage.updateApiKeyLastUsed(keyRecord.id);
  
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create default WhatsApp account if none exists
  const accounts = await storage.getAllWhatsAppAccounts();
  if (accounts.length === 0) {
    console.log('No WhatsApp accounts found. Creating default account...');
    await storage.createWhatsAppAccount({
      name: 'Default WhatsApp',
      password: 'default',
      sessionId: 'default-session',
    });
    console.log('Default WhatsApp account created successfully.');
  }

  // Initialize all WhatsApp accounts on server start
  initializeAllWhatsAppAccounts();

  /**
   * POST /api/keys
   * Creates a new API key
   */
  app.post("/api/keys", async (req, res) => {
    try {
      const validation = createApiKeySchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          success: false,
          error: validation.error.errors[0].message
        });
      }

      let apiKeyValue: string;
      
      if (validation.data.customKey && validation.data.customKey.trim()) {
        let customKey = validation.data.customKey.trim();
        if (!customKey.startsWith('wapi_')) {
          customKey = `wapi_${customKey}`;
        }
        
        const existingKey = await storage.getApiKeyByKey(customKey);
        if (existingKey) {
          return res.status(400).json({
            success: false,
            error: "هذا الرمز المخصص مستخدم بالفعل. الرجاء اختيار رمز آخر."
          });
        }
        
        apiKeyValue = customKey;
      } else {
        apiKeyValue = generateApiKey();
      }

      const apiKey = await storage.createApiKey({
        name: validation.data.name,
        key: apiKeyValue,
        isActive: true,
      });

      return res.json({
        success: true,
        apiKey: {
          id: apiKey.id,
          name: apiKey.name,
          key: apiKeyValue,
          isActive: apiKey.isActive,
          createdAt: apiKey.createdAt,
        },
        message: "API key created successfully! Save this key securely - it won't be shown again."
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to create API key"
      });
    }
  });

  /**
   * GET /api/keys
   * Lists all API keys (without showing the actual key values)
   */
  app.get("/api/keys", async (_req, res) => {
    try {
      const keys = await storage.getAllApiKeys();
      
      const sanitizedKeys = keys.map(key => ({
        id: key.id,
        name: key.name,
        keyPreview: `${key.key.substring(0, 12)}...`,
        isActive: key.isActive,
        createdAt: key.createdAt,
        lastUsedAt: key.lastUsedAt,
      }));

      return res.json({
        success: true,
        keys: sanitizedKeys
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch API keys"
      });
    }
  });

  /**
   * PATCH /api/keys/:id
   * Toggles API key active status
   */
  app.patch("/api/keys/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { isActive } = req.body;

      if (typeof isActive !== 'boolean') {
        return res.status(400).json({
          success: false,
          error: "isActive must be a boolean value"
        });
      }

      const updated = await storage.updateApiKey(id, { isActive });

      if (!updated) {
        return res.status(404).json({
          success: false,
          error: "API key not found"
        });
      }

      return res.json({
        success: true,
        message: `API key ${isActive ? 'enabled' : 'disabled'} successfully`
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to update API key"
      });
    }
  });

  /**
   * DELETE /api/keys/:id
   * Deletes an API key
   */
  app.delete("/api/keys/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteApiKey(id);

      if (!deleted) {
        return res.status(404).json({
          success: false,
          error: "API key not found"
        });
      }

      return res.json({
        success: true,
        message: "API key deleted successfully"
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to delete API key"
      });
    }
  });

  /**
   * GET /api/status
   * Returns current WhatsApp connection status and QR code if available
   */
  app.get("/api/status", async (_req, res) => {
    try {
      const accounts = await storage.getAllWhatsAppAccounts();
      
      if (accounts.length === 0) {
        return res.json({
          ready: false,
          qrCode: null,
          message: "No WhatsApp accounts configured"
        });
      }

      const connectedAccount = accounts.find(acc => acc.isConnected);
      const accountToCheck = connectedAccount || accounts[0];
      
      const state = getAccountState(accountToCheck.sessionId);
      
      if (!state) {
        return res.json({
          ready: false,
          qrCode: null,
          message: "Initializing WhatsApp connection..."
        });
      }

      const ready = state.isReady;
      const qrCode = state.qrCode;
      
      res.json({
        ready,
        qrCode,
        message: ready 
          ? "WhatsApp is connected and ready to send messages" 
          : qrCode 
            ? "Scan QR code to connect WhatsApp" 
            : state.lastError || "Connecting to WhatsApp..."
      });
    } catch (error: any) {
      res.status(500).json({
        ready: false,
        qrCode: null,
        message: error.message || "Error checking status"
      });
    }
  });

  /**
   * POST /api/send
   * Sends a WhatsApp message to the specified phone number
   * Requires X-API-Key header for authentication
   * 
   * Request headers:
   * {
   *   "X-API-Key": "wapi_your_api_key_here"
   * }
   * 
   * Request body:
   * {
   *   "number": "201234567890",  // Phone number with country code
   *   "message": "Hello from WhatsApp API!"
   * }
   */
  app.post("/api/send", validateApiKey, async (req, res) => {
    try {
      const validation = sendMessageSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          success: false,
          error: validation.error.errors[0].message
        });
      }

      const { number, message } = validation.data;
      const cleanNumber = number.replace(/[\s\-\(\)]/g, '');

      const accounts = await storage.getAllWhatsAppAccounts();
      const connectedAccount = accounts.find(acc => acc.isConnected);
      
      if (!connectedAccount) {
        return res.status(400).json({
          success: false,
          error: "No WhatsApp account is connected. Please scan QR code first."
        });
      }

      const result = await sendMessageFromAccount(connectedAccount.sessionId, cleanNumber, message);
      
      if (result.success) {
        return res.json({
          success: true,
          message: "Message sent successfully!",
          messageId: result.messageId
        });
      } else {
        return res.status(400).json({
          success: false,
          error: result.error
        });
      }
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  });

  /**
   * POST /api/send-direct
   * Sends a WhatsApp message without API key (for internal use from frontend only)
   */
  app.post("/api/send-direct", async (req, res) => {
    try {
      const validation = sendMessageSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          success: false,
          error: validation.error.errors[0].message
        });
      }

      const { number, message } = validation.data;
      const cleanNumber = number.replace(/[\s\-\(\)]/g, '');
      
      const accounts = await storage.getAllWhatsAppAccounts();
      const connectedAccount = accounts.find(acc => acc.isConnected);
      
      if (!connectedAccount) {
        return res.status(400).json({
          success: false,
          error: "No WhatsApp account is connected. Please scan QR code first."
        });
      }

      const result = await sendMessageFromAccount(connectedAccount.sessionId, cleanNumber, message);
      
      if (result.success) {
        return res.json({
          success: true,
          message: "Message sent successfully!",
          messageId: result.messageId
        });
      } else {
        return res.status(400).json({
          success: false,
          error: result.error
        });
      }
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  });

  /**
   * POST /api/visit
   * Tracks visitor access to the server
   */
  app.post("/api/visit", async (req, res) => {
    try {
      const timestamp = new Date().toISOString();
      const ip = req.ip || req.connection.remoteAddress || 'unknown';
      console.log(`[VISIT TRACKING] ${timestamp} - Visitor from: ${ip}`);
      
      return res.json({
        success: true,
        message: "Visit tracked",
        timestamp
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to track visit"
      });
    }
  });

  /**
   * POST /api/bulk-send/start
   * Start bulk sending messages
   */
  app.post("/api/bulk-send/start", async (req, res) => {
    try {
      const { tasks } = req.body;
      
      if (!tasks || !Array.isArray(tasks) || tasks.length === 0) {
        return res.status(400).json({
          success: false,
          error: "Tasks array is required"
        });
      }

      await storage.saveBulkSendProgress({
        tasks,
        currentIndex: 0,
        startedAt: new Date().toISOString(),
        lastUpdatedAt: new Date().toISOString()
      });

      return res.json({
        success: true,
        message: "Bulk send started"
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to start bulk send"
      });
    }
  });

  /**
   * GET /api/bulk-send/progress
   * Get current bulk send progress
   */
  app.get("/api/bulk-send/progress", async (_req, res) => {
    try {
      const progress = await storage.getBulkSendProgress();
      return res.json({
        success: true,
        progress
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to get progress"
      });
    }
  });

  /**
   * POST /api/bulk-send/update-progress
   * Update bulk send progress
   */
  app.post("/api/bulk-send/update-progress", async (req, res) => {
    try {
      const { currentIndex } = req.body;
      const progress = await storage.getBulkSendProgress();
      
      if (!progress) {
        return res.status(404).json({
          success: false,
          error: "No active bulk send session"
        });
      }

      progress.currentIndex = currentIndex;
      progress.lastUpdatedAt = new Date().toISOString();
      await storage.saveBulkSendProgress(progress);

      return res.json({
        success: true,
        message: "Progress updated"
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to update progress"
      });
    }
  });

  /**
   * POST /api/bulk-send/complete
   * Complete bulk send session
   */
  app.post("/api/bulk-send/complete", async (_req, res) => {
    try {
      await storage.clearBulkSendProgress();
      return res.json({
        success: true,
        message: "Bulk send completed"
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to complete bulk send"
      });
    }
  });

  /**
   * POST /api/whatsapp/reset-session
   * Resets the WhatsApp session and generates a new QR code
   * This deletes the local session data but does NOT logout from the device
   */
  app.post("/api/whatsapp/reset-session", async (_req, res) => {
    try {
      const accounts = await storage.getAllWhatsAppAccounts();
      
      if (accounts.length === 0) {
        return res.status(400).json({
          success: false,
          error: "No WhatsApp accounts found"
        });
      }

      const accountToReset = accounts[0];
      
      await deleteWhatsAppAccountSession(accountToReset.sessionId);
      
      setTimeout(async () => {
        await initializeWhatsAppAccount(accountToReset.sessionId);
      }, 2000);

      return res.json({
        success: true,
        message: "Session reset successfully. New QR code will appear shortly."
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to reset session"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
